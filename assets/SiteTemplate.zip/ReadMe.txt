Responsive HTML5 website template for promoting your mobile app

Theme name:
=======================================================================
Delta

Theme version:
=======================================================================
v3.2

Release Date:
=======================================================================
11 Nov 2017

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Facebook: https://www.facebook.com/3rdwavethemes/
Twitter: 3rdwave_themes

